# VSRP POC — Vessel Schedule Recovery Problem: First Proof of Concept

## What You're Building (Plain English)

You are building a **simulation + optimization dashboard** that shows:

1. A container ship is sailing a fixed route (e.g., Asia → US West Coast → back).
2. A disruption hits (e.g., port congestion at Los Angeles, like the real 2021 COVID surge).
3. The system automatically finds the **cheapest recovery** — should the ship speed up (more fuel cost) or skip a port (rollover penalty)?
4. The result is shown visually: delay timeline, cost breakdown, Pareto trade-off curve.

This directly mirrors what both conference papers study, but adds the **mathematical optimization layer** the professor requires.

---

## What the Professor Wants (Mapped to Your POC)

| Professor's Requirement | What We Build |
|---|---|
| Base journal paper (Brouer 2013, EJOR) | We implement his exact MIP objective function |
| OR/Optimization stream | MILP solver (PuLP/scipy) for speed + skip decisions |
| ML/AI stream | Simple trained classifier (XGBoost/sklearn) predicting skip probability |
| Data audit | Use open AIS-derived synthetic data + real port delay stats |
| Presentation | Interactive web dashboard showing all results |

---

## Architecture Overview

```
vsrp_poc/
├── data/
│   ├── synthetic_route.csv          # Synthetic liner service (Asia→USWC→Asia)
│   ├── port_params.csv              # Port congestion, berths, handling rates
│   └── disruption_scenarios.csv    # Several disruption events to test
├── src/
│   ├── data_generator.py           # Generates synthetic data from paper formulas
│   ├── vsrp_optimizer.py           # Core MILP optimization (Brouer 2013 model)
│   ├── simulation_agent.py         # Heuristic multi-agent sim (Kowatari model)
│   ├── ml_classifier.py            # XGBoost skip predictor
│   └── metrics.py                  # Cost calculations, delay metrics
├── dashboard/
│   ├── index.html                  # Main interactive dashboard
│   ├── app.js                      # Dashboard logic
│   └── style.css                   # Premium styling
├── run_poc.py                      # Master script: runs everything end-to-end
└── requirements.txt
```

---

## Module 1 — Synthetic Data Generation

**Why synthetic?** Both papers used proprietary MDS Transmodal + Lloyd's List Intelligence data (you don't have access). Synthetic data calibrated to the paper's own numbers is academically valid for a POC.

### Route: Transpacific FP1-style pendulum route
Based directly on Watanabe et al.'s analysis of **THE ALLIANCE FP1** service:

```
Ports: Yokohama → Shanghai → Ningbo → Yantian → Los Angeles → Long Beach → Oakland → Yokohama
Vessels deployed: 10 ships
Frequency: weekly (headway = 168 hours)
Cycle time: 10 × 168 = 1680 hours
```

### Leg distances (from SeaRoute approximations):
```
Yokohama → Shanghai:         1,094 nm
Shanghai → Ningbo:             97 nm
Ningbo → Yantian:             734 nm
Yantian → Los Angeles:      5,445 nm
Los Angeles → Long Beach:      21 nm
Long Beach → Oakland:         386 nm
Oakland → Yokohama:         4,536 nm
```

### Vessel parameters (from Kowatari Table I):
```
TEU capacity: 14,000 TEU (ultra-large vessel)
v_def (default speed): computed from formula (5) in Kowatari
v_min = 10 knots, v_max = 25 knots
δ = 5.813 × 10⁻⁵ √ton / knot³  (Kowatari Table VII)
Berthing time baseline = (TEU/8000) × 24 = 42 hours
```

### Disruption scenario (mirroring 2021 reality):
```
Disruption point: Los Angeles port
Type: Congestion surge (handling efficiency drops to 50%)
Induced delay: +120 to +168 hours anchorage wait (matches Watanabe Table I: LA = 163.9 hr)
Disruption start: simulation timestep 1200
```

---

## Module 2 — MILP Optimization Model (Brouer 2013)

### Objective Function (this is what you present to the professor):

```
minimize Σᵢ [
    δ · √(10·TEU) · vᵢ³ · τᵢ        (fuel cost — cubic in speed)
  + Σₚ cₚᵇᵉʳᵗʰ · Tₚᵇᵉʳᵗʰ            (port handling fees)
  + π · Dᵢ                           (delay penalty per hour)
  + Σₚ∈skip ωₚ · TEUₚˢᵏⁱᵖ           (omission/transshipment penalty)
]
```

### Decision Variables:
- `v[leg]` — continuous: sailing speed on each leg (knots), bounded [10, 25]
- `x[port]` — binary: 1 = skip this port, 0 = call normally

### Key Constraints:
1. Speed bounds: `10 ≤ v[leg] ≤ 25`
2. Time conservation: `Σ (dist[leg]/v[leg]) + Σ T_berth[port] × (1-x[port]) ≤ T_cycle`
3. Berth window: vessel can't berth before slot opens
4. If disrupted port has >T_skip delay, skip binary forced to consider 1
5. Minimum calls: can't skip more than 2 consecutive ports (cargo connection constraint)

### Solver: PuLP (open-source, no license needed)

**What the optimizer returns:**
- Optimal speed per leg (e.g., "speed up from 18 kn to 23 kn on Yantian→LA leg")
- Skip/no-skip decision per port
- Total cost breakdown: fuel + handling + delay + penalty

---

## Module 3 — Multi-Agent Heuristic Simulation (Kowatari 2025)

Implements equations (6), (7), (8), (9) from Kowatari's paper directly in Python:

```python
# Speed adjustment (Eq. 6):
v_i = clip(v_def × (1 + α×D_i) × (1 - β×Q_j), v_min, v_max)

# Port skip decision (Eq. 7):
if delay(t) >= T_skip:
    next_port = current_port + 2  # skip next
else:
    next_port = current_port + 1

# Berthing time with congestion (Eq. 8-9):
C_p(q) = piecewise(q, L, H, m)
T_berth_actual = T_berth_s × C_p(q) × H_p
```

This runs a 1-year simulation with 10 vessels on the route, producing:
- Time series of delay per vessel
- Queue length at each port over time
- Total fuel consumption
- Number of skips triggered

---

## Module 4 — ML Skip Classifier (XGBoost)

**Why:** The 2025 Ocean Engineering paper showed a hybrid CLPSO-XGBoost classifier predicts port-skipping with 86% accuracy. We reproduce this concept using our synthetic data.

### Feature Engineering (from paper's dominant features):
```python
features = [
    'current_delay_hours',     # accumulated delay at decision point
    'vessel_teu',              # vessel size
    'port_queue_length',       # destination queue
    'leg_distance_nm',         # distance to next port
    'port_skipping_rate_hist', # historical skip rate at this port (from Watanabe Table II-IV)
    'handling_efficiency',     # current port H_p factor
    'fuel_price_proxy',        # bunker price (constant in POC)
    'days_since_disruption',   # time elapsed since disruption started
]
label = 'skipped'  # binary: did the ship actually skip?
```

### Training data: Run the heuristic simulation 100 times with random disruption parameters → collect 10,000+ decision events → label each with actual skip outcome → train XGBoost.

### Output: probability score that a vessel will skip a given port given current state.

---

## Module 5 — Interactive Dashboard

A single-page HTML/CSS/JS dashboard showing:

### Panel 1: Route Map
- Visual circular route diagram (ports as nodes, legs as arcs)
- Color-coded: green = normal, red = congested, yellow = skipped
- Animated vessel position indicator

### Panel 2: Disruption Timeline
- Slider: select disruption severity (delay hours: 24, 72, 120, 168)
- Shows how delay propagates upstream/downstream

### Panel 3: Optimizer Results
- Side-by-side: "Before Recovery" vs "After Optimization"
- Speed profile per leg (bar chart)
- Skip/no-skip decision badges per port
- Total cost: fuel / delay / penalties breakdown (donut chart)

### Panel 4: Pareto Trade-Off Curve
- X-axis: Total Fuel Cost
- Y-axis: Total Delay (hours)
- Each point = one (α, β) combination from the simulation
- Pareto frontier highlighted in gold
- This is EXACTLY Figure 5 from Kowatari's paper, but built from your own code

### Panel 5: ML Classifier Output
- Input sliders: delay, queue length, TEU, distance
- Real-time XGBoost probability bar: "Skip probability: 73%"
- Feature importance chart

---

## Technology Stack

| Component | Tool | Why |
|---|---|---|
| Optimization | `PuLP` + `CBC solver` | Free, no license, MIP capable |
| Simulation | Pure Python (numpy) | Fast, matches Kowatari's approach |
| ML | `XGBoost` + `scikit-learn` | Standard, paper uses it |
| Data | Synthetic + real port stats | No proprietary data needed |
| Dashboard | HTML/CSS/JS (Chart.js, D3.js) | No framework needed, runs in browser |
| API glue | Python `http.server` or Flask | Connects dashboard to Python models |

---

## Step-by-Step Build Sequence

### Step 0: Setup (5 min)
```bash
mkdir vsrp_poc && cd vsrp_poc
pip install pulp numpy pandas scikit-learn xgboost flask
```

### Step 1: Generate synthetic data (data_generator.py)
- Hardcode the 8-port route with Kowatari's formulas
- Generate 1-year simulation baseline (no disruption)
- Inject disruption: LA port congestion at month 6
- Output: CSVs with port call logs, delay logs, speed logs

### Step 2: Run MILP optimizer (vsrp_optimizer.py)
- Take the disrupted schedule as input
- Solve for optimal speed + skip decisions
- Compare cost: disrupted (no recovery) vs optimized recovery
- Key number to report: "X% cost reduction" (Brouer got 58%, aim for 20-40%)

### Step 3: Run heuristic simulation (simulation_agent.py)
- Run 25 scenarios varying (α, β) pairs
- Collect delay, fuel, queue metrics per scenario
- Generate Pareto frontier data

### Step 4: Train ML classifier (ml_classifier.py)
- Generate 5,000 training examples from simulation
- Train XGBoost with 80/20 split
- Report accuracy, precision, recall, feature importances

### Step 5: Build dashboard (dashboard/)
- Static HTML with Chart.js for all charts
- Flask backend serving JSON from Python models
- Run with: `python run_poc.py` → opens browser

---

## What to Present Tomorrow

### Slide 1: Problem Statement (30 sec)
> "Container ships lose schedule reliability when ports congest. The VSRP asks: should we speed up (costs fuel) or skip ports (costs cargo penalties)?"

### Slide 2: The Math (Brouer 2013, your optimizer)
> Show the objective function. Say: "We implemented this as a Mixed-Integer Linear Program."

### Slide 3: Live Demo — Dashboard
> Drag the disruption slider. Show costs change. Show skip decisions change.

### Slide 4: ML Skip Predictor
> Show XGBoost accuracy. Show feature importances. Connect to paper's 86% claim.

### Slide 5: Pareto Trade-Off
> "Every point is a different recovery strategy. Gold line is the efficient frontier. Real-world operators would pick a point based on their cost priorities."

### Slide 6: What's Next
> "Replace synthetic data with open AIS (MarineCadastre), extend to multi-vessel, add DRL."

---

## Open Questions / Decisions

> [!IMPORTANT]
> **For the professor:** This POC uses synthetic data calibrated to the papers' own parameters. If the professor requires real AIS data, MarineCadastre NOAA data can be downloaded free and preprocessed in ~2 hours as described in Module 4 of the AI audit.

> [!NOTE]
> **ML paper citation:** The Ocean Engineering 2025 paper is Q1 Elsevier but not on the professor's named list (TR-B/E, EJOR, C&OR). Mention this proactively: "We implemented the XGBoost skip predictor inspired by [Ocean Engineering 2025]; for the final thesis we will source a DRL paper from TR-B/E."

> [!TIP]
> **Biggest "wow" moment for the professor:** The Pareto curve (Panel 4) directly demonstrates you understand the fundamental trade-off the professor described: "delay vs. fuel cost vs. penalty cost." Make sure this is shown prominently.

---

## Verification Plan

- Optimizer produces cost reduction (target: 20–50% vs. no-recovery baseline)
- Simulation Pareto curve matches qualitative shape of Kowatari Fig. 5
- XGBoost accuracy > 75% (random synthetic data may limit this, but structure is what matters)
- Dashboard loads in browser, all charts render, slider updates all panels
